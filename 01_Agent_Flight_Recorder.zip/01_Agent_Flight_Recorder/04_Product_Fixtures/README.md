# Fixture scope

AFR structural request/response examples are in ../02_Product_Contracts/examples/. Recorded replay format and behavior are specified in the canonical normative baseline; no working replay server is included.

Canonical generators, reference oracles and tests remain in ../05_Shared_Baseline.
